package org.onlineshoppingportal.controller;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.swing.JPopupMenu;

import org.apache.log4j.Logger;
import org.onlineshoppingportal.authentication.SecurityService;
import org.onlineshoppingportal.dao.AccountDao;
import org.onlineshoppingportal.dao.CategorysDao;
import org.onlineshoppingportal.dao.OrderDao;
import org.onlineshoppingportal.dao.ProductDao;
import org.onlineshoppingportal.entity.Account;
import org.onlineshoppingportal.dao.SlidesDao;
import org.onlineshoppingportal.entity.Order;
import org.onlineshoppingportal.entity.Products;
//import org.onlineshoppingportal.entity.Product;
import org.onlineshoppingportal.exceptions.AlreadyLoginException;
import org.onlineshoppingportal.exceptions.NoOrderFoundException;
import org.onlineshoppingportal.exceptions.ProductOutOfStockException;
import org.onlineshoppingportal.validator.AccountValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@Controller
//Enable Hibernate Transaction.
@Transactional
//Need to use RedirectAttributes
@EnableWebMvc
public class MainController {

	public static Logger logger = Logger.getLogger(MainController.class);

	@Autowired
	private OrderDao orderDAO;

	@Autowired
	private ProductDao productDAO;

	@Autowired
	private AccountDao accountDao;

	@Autowired
	private SecurityService securityService;

	@Autowired
	private AccountValidator accountValidator;

	@Autowired
	private SlidesDao slidesDao;

	@Autowired
	private CategorysDao categorysDao;

	@InitBinder
	public void myInitBinder(WebDataBinder dataBinder) {
		Object target = dataBinder.getTarget();
		if (target == null) {
			return;
		}
		if (logger.isDebugEnabled())
			logger.debug("Target =" + target);

		if (target.getClass() == Account.class)
			dataBinder.setValidator(accountValidator);

	}

	@RequestMapping("/403")
	public String accessDenied(HttpServletRequest request) {
		logger.error("Access Denied URL =" + request.getRequestURL());
		return "/403";
	}

	@RequestMapping("/contact")
	public String showContact(Model model) {
		model.addAttribute("categorys", categorysDao.GetDataCategory());
		return "contact";
	}

	@RequestMapping("/blog-details")
	public String showBlog(Model model) {
		model.addAttribute("categorys", categorysDao.GetDataCategory());
		return "blog-details";
	}

	// GET: Show Login Page
	@RequestMapping(value = { "/login" }, method = RequestMethod.GET)
	public String login(HttpServletRequest request, Model model) {
		if (request.getUserPrincipal() != null)
			throw new AlreadyLoginException();
		model.addAttribute("categorys", categorysDao.GetDataCategory());
		return "login";
	}

	// GET: Show Sign Up Page
	@RequestMapping(value = { "/signUp" }, method = RequestMethod.GET)
	public String signUpForm(Model model, HttpServletRequest request) {
		if (request.getUserPrincipal() != null)
			throw new AlreadyLoginException();
		model.addAttribute("account", new Account());
		model.addAttribute("categorys", categorysDao.GetDataCategory());
		return "signUp";
	}

	@RequestMapping(value = { "/signUp" }, method = RequestMethod.POST)
	public String signUpFormProcess(@Validated Account account, BindingResult bindingResult,
			HttpServletRequest request) {
		if (request.getUserPrincipal() != null)
			throw new AlreadyLoginException();

		if (bindingResult.hasErrors()) {
			return "signUp";
		}
		String password = account.getPassword();
		accountDao.saveAccount(account);
		securityService.autologin(account.getUserName(), password);
		return "redirect:/index";
	}

	// Product List page.
	@RequestMapping({ "/", "/index" })
	public String listProductHandler(Model model) {
		model.addAttribute("slides", slidesDao.GetDataSlide());
		model.addAttribute("categorys", categorysDao.GetDataCategory());
		model.addAttribute("products", productDAO.getAllProducts());
		return "index";
	}

	@RequestMapping("/single-product")
	public String listProductHand(HttpServletRequest request, Model model, //
			@RequestParam(value = "id", defaultValue = "") String id) {
		if (id.isEmpty()) {
			return "redirect:/index";
		}

		model.addAttribute("categorys", categorysDao.GetDataCategory());
		model.addAttribute("products", productDAO.findProduct(id));

		return "single-product";
	}


	@RequestMapping(value = { "/purchase" }, method = RequestMethod.POST)
	// Avoid UnexpectedRollbackException
	@Transactional(propagation = Propagation.NEVER)
	public String purchaseProduct(HttpServletRequest request, Model model) {
		if (request.getUserPrincipal() == null)
			return "redirect:/login";
		String code = request.getParameter("id");
		int quantity = Integer
				.parseInt(request.getParameter("quantity")==null ? "1" : request.getParameter("quantity"));
		Order order = orderDAO.saveOrder(code, quantity, securityService.findLoggedInUsername());
		model.addAttribute("order", order);
		if (logger.isInfoEnabled())
			logger.info("Product purchased having code " + code + ", quantity " + quantity);

		return "redirect:/index";
	}
	 //DELETE SAN PHAM
	@RequestMapping(value = { "/deleteOrder" })
	public String deleteOrder(HttpServletRequest request, Model model) {
		String id = request.getParameter("id");
		orderDAO.deleteOrder(id);
		
		return getOrderByUsername(request, model);
	}
	
	 //UPDATE SAN PHAM
	@RequestMapping(value = { "/updateOrder" })
	public String updateOrder(HttpServletRequest request, Model model) {
		//String id = request.getParameter("id");
		int quantity = Integer
				.parseInt(request.getParameter("quantity")==null ? "1" : request.getParameter("quantity"));
		orderDAO.updateOrder(quantity,securityService.findLoggedInUsername());
		
		return getOrderByUsername(request, model);
	}

	@RequestMapping(value = { "/orderList" }, method = RequestMethod.GET)
	public String getOrderByUsername(HttpServletRequest request, Model model) {
		List<Order> list = orderDAO.getOrdersByUserName(securityService.findLoggedInUsername());
		model.addAttribute("categorys", categorysDao.GetDataCategory());
		model.addAttribute("list", list);
		return "cart";
	}

}

insert into role values(1,'USER');
insert into role values(2,'ADMIN');

insert into products values('S001','Java',150,20);
insert into products values('S002','Java8',160,1);
insert into products values('S003','node',170,0);
insert into products values('S004','angular',180,2);
insert into products values('S005','jsp',190,5);
insert into products values('S006','spring',120,10);
insert into products values('S007','hibernate',110,19);



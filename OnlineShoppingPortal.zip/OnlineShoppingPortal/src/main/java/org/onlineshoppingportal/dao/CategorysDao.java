package org.onlineshoppingportal.dao;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.onlineshoppingportal.entity.Categorys;

@Transactional
@Repository
public class CategorysDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@SuppressWarnings("unchecked")
	public List<Categorys> GetDataCategory(){
		Session session = sessionFactory.getCurrentSession();
	     Criteria crit = session.createCriteria(Categorys.class);
		return crit.list();
	} 
}
package org.onlineshoppingportal.dao;

import java.util.List;

import org.onlineshoppingportal.entity.Products;

public interface ProductDao {

	public List<Products> findProduct(String code);
	public Products getProduct(String code);
    public List<Products> getAllProducts();
   
}
